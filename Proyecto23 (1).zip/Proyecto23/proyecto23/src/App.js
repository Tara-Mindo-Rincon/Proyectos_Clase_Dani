import TarotCard from "./TarotCard";

function App() {
  return <TarotCard />;
}

export default App;
