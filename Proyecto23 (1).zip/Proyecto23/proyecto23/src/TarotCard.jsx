import { useEffect, useState } from "react";
import "./TarotCard.css";

export default function TarotCard() {
  const [card, setCard] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [error, setError] = useState("");

  const fetchRandomCard = () => {
    setLoading(true);
    setError("");
    fetch("https://tarotapi.dev/api/v1/cards/random")
      .then((res) => res.json())
      .then((data) => {
        setCard(data.cards[0]);
        setLoading(false);
      })
      .catch(() => {
        setError("Failed to load a random card. Try again.");
        setLoading(false);
      });
  };

  const fetchSearchCard = (e) => {
    e.preventDefault();
    if (!searchTerm.trim()) {
      setError("Please enter a card name to search.");
      return;
    }
    setLoading(true);
    setError("");
    fetch(`https://tarotapi.dev/api/v1/cards/search?q=${encodeURIComponent(searchTerm)}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.cards && data.cards.length > 0) {
          setCard(data.cards[0]);
        } else {
          setError("No card found with that name.");
          setCard(null);
        }
        setLoading(false);
      })
      .catch(() => {
        setError("Error fetching card information.");
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchRandomCard();
  }, []);

  return (
    <div className="tarot-container">
      <h1 className="title">Tarot Card Reader</h1>

      {/* Search bar */}
      <form onSubmit={fetchSearchCard} className="search-bar">
        <input
          type="text"
          placeholder="Search card (e.g. Queen of Wands)"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <button type="submit">Search</button>
      </form>

      {loading && <p className="loading">Loading card...</p>}
      {error && <p className="error">{error}</p>}

      {!loading && card && (
        <div className="tarot-card">
          <h2>{card.name}</h2>
          <p className="suit">({card.suit})</p>

          <div className="section">
            <h3>Upright Meaning:</h3>
            <p>{card.meaning_up}</p>
          </div>

          <div className="section">
            <h3>Reversed Meaning:</h3>
            <p>{card.meaning_rev}</p>
          </div>

          <p className="desc">{card.desc}</p>
        </div>
      )}

      <button className="reload-btn" onClick={fetchRandomCard}>
        Generate Random Card
      </button>
    </div>
  );
}