export default function getScrollParent(node: Node): HTMLElement;
