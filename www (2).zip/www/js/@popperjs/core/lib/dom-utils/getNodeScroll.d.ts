import type { Window } from "../types";
export default function getNodeScroll(node: Node | Window): {
    scrollLeft: any;
    scrollTop: any;
};
